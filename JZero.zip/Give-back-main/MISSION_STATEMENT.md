## Mission Statement

I searched everywhere for a good, transparent astrology calculator—something open, accurate enough to learn from, and cleanly coded. I couldn’t find one.  

So I built one.  

This framework isn’t perfect; it’s a foundation. The math works, the structure’s there, and it can serve as a starting point for anyone who wants to understand how astrology software actually ticks. My hope is that another astro-developer—or maybe a few—will take it further.  

If this project inspires someone to build the next generation of astrology tools, then it’s done its job.  

**– The Decan Project**
